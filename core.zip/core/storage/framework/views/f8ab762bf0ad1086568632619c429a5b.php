<?php $__env->startSection('content'); ?>
    <section class="container stylization maincont">

        <?php echo $__env->make('home.partials.breadcubs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <h1 class="main-ttl"><span>Login</span></h1>
        <div class="row"style="display: flex;justify-content: center">
            <div class="col-md-6">
                <form method="POST" action="<?php echo e(route('login.post')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Email/Phone<span
                                class="text-danger">*</span></label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="inputEmail3" placeholder="Enter Email or Phone"
                                name="type" value="<?php echo e(old('type')); ?>">
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label" style="margin-top: 20px">Password<span
                                class="text-danger">*</span></label>
                        <div class="col-sm-10" style="text-align: start">
                            
                            <input type="password" class="form-control" id="inputPassword3" placeholder="Enter Password"
                                name="password">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label"></label>
                        <div class="col-sm-10 " style="display: flex;justify-content: start;margin-top: 10px">
                            <span class=""> Dont have account? <a href="<?php echo e(route('register')); ?>">Register</a></span>
                            <hr>
                            <span class=""><a href="<?php echo e(route('forgot')); ?>">Forgot Password</a></span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label"></label>
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">Sign in</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>



    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/home/login.blade.php ENDPATH**/ ?>