  <table id="myTable">
      <thead>
          <tr>
              <th colspan="6"></th>
          </tr>
          <tr>
              <th colspan="6"></th>
          </tr>
          <tr>
              <th colspan="6">
                  <center><b>
                          <h2>All Discount</h2>
                      </b></center>
              </th>
          </tr>
          <tr>
              <th colspan="6"></th>
          </tr>
      </thead>
      <thead>
          <tr>
              <th>No</th>
              <th>Name</th>
              <th>Disc</th>
              <th>Last Price</th>
              <th>Final Price</th>
              <th>Status</th>
          </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  <td><?php echo e($t->product->product_name); ?></td>
                  <td><?php echo e($t->disc); ?>%</td>
                  <td>
                      <?php echo e(nb($t->product->price)); ?>

                  </td>
                  <td> <?php echo e(nb($t->final_amount)); ?></td>
                  <td><?php echo status($t->status); ?></td>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/dashboard/report/excel/discount.blade.php ENDPATH**/ ?>