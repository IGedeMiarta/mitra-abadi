  <table id="myTable">
      <thead>
          <tr>
              <th colspan="3"></th>
          </tr>
          <tr>
              <th colspan="3"></th>
          </tr>
          <tr>
              <th colspan="3">
                  <center><b>
                          <h2>All Brand</h2>
                      </b></center>
              </th>
          </tr>
          <tr>
              <th colspan="6"></th>
          </tr>
      </thead>
      <thead>
          <tr>
              <th>No</th>
              <th>Name</th>
              <th>Created At</th>
          </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  <td><?php echo e($t->name); ?></td>
                  <td><?php echo e(dt($t->created_at)); ?></td>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      </tbody>
  </table>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/dashboard/report/excel/brand.blade.php ENDPATH**/ ?>