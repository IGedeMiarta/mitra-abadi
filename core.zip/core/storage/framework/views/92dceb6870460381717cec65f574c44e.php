<?php $__env->startPush('style'); ?>
    <style>
        .disableBtn {
            pointer-events: none;
            cursor: default;

        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="container stylization maincont">

        <?php echo $__env->make('home.partials.breadcubs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <h1 class="main-ttl"><span><?php echo e($title ?? ''); ?></span></h1>
        <!-- Cart Items - start -->
        <div class="cart-items-wrap">
            <table class="cart-items">
                <thead>
                    <tr>
                        <td class="cart-ttl">Products</td>
                        <td class="cart-quantity">Qty</td>
                        <td class="cart-price">Price</td>
                        <td class="cart-summ">Status</td>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td class="cart-ttl">
                                <a href="<?php echo e(url('invoice/' . $item->Invoice)); ?>" target="_blank"
                                    style="color: #7071E8">#<?php echo e($item->Invoice); ?></a>

                                <?php $__currentLoopData = $item->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p><?php echo e($i + 1 . '. ' . $d->product->product_name); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </td>
                            <td class="cart-quantity">
                                <p class="cart-qnt"><?php echo e($item->details->count()); ?></p>
                            </td>
                            <td class="cart-price">
                                <b><?php echo e(nb($item->amount)); ?></b>
                            </td>

                            <td class="cart-summ">
                                <b><?php echo $item->status(); ?></b>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
        </div>
        <!-- Cart Items - end -->

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/home/invoice.blade.php ENDPATH**/ ?>