<!-- Topbar - start -->
<div class="header_top">
    <div class="container">
        <ul class="contactinfo nav nav-pills">
            <li>
                <i class='fa fa-phone'></i> <?php echo e(app_data('phone')); ?>

            </li>
            <li>
                <i class="fa fa-envelope"></i> <?php echo e(app_data('email')); ?>

            </li>
        </ul>
        <!-- Social links -->
        <ul class="social-icons nav navbar-nav">
            <li>
                <a href="http://facebook.com/" rel="nofollow" target="_blank">
                    <i class="fa fa-facebook"></i>
                </a>
            </li>
            <li>
                <a href="http://twitter.com/" rel="nofollow" target="_blank">
                    <i class="fa fa-twitter"></i>
                </a>
            </li>
            <li>
                <a href="http://instagram.com/" rel="nofollow" target="_blank">
                    <i class="fa fa-instagram"></i>
                </a>
            </li>
        </ul>
    </div>
</div>
<!-- Topbar - end -->
<!-- Logo, Shop-menu - start -->
<div class="header-middle">
    <div class="container header-middle-cont">
        <div class="toplogo">
            <a href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('logo.png')); ?>" alt="AllStore - MultiConcept eCommerce Template">
            </a>
        </div>
        <div class="shop-menu">
            <ul>

                <?php if(!auth()->user()): ?>
                    <li class="topauth">
                        <a href="<?php echo e(url('register')); ?>">
                            <i class="fa fa-lock"></i>
                            <span class="shop-menu-ttl">Registration</span>
                        </a>
                        <a href="<?php echo e(url('login')); ?>">
                            <span class="shop-menu-ttl">Login</span>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="topauth">
                        <?php if(auth()->user()->role == 'cust'): ?>
                            <a href="<?php echo e(url('profile')); ?>" style="color: green">
                                <i class="fa fa-user" style="color: green"></i>
                                <span class="shop-menu-ttl"><?php echo e(auth()->user()->name); ?></span>
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(url(auth()->user()->role . '/dashboard')); ?>" style="color: green">
                                <i class="fa fa-user" style="color: green"></i>
                                <span class="shop-menu-ttl"><?php echo e(auth()->user()->name); ?></span>
                            </a>
                        <?php endif; ?>

                        <a href="<?php echo e(url('chart')); ?>" style="color: blue">
                            <i class="fa fa-shopping-cart" style="color: blue"></i>
                            <span class="shop-menu-ttl">Cart</span> <span class="badge "
                                style="color: white;background-color: blue"><b class="userID"
                                    data-user_id="<?php echo e(auth()->user()->id); ?>">0</b></span>
                        </a>
                    </li>
                <?php endif; ?>

            </ul>
        </div>
    </div>
</div>
<!-- Logo, Shop-menu - end -->
<!-- Topmenu - start -->
<div class="header-bottom">
    <div class="container">
        <nav class="topmenu">
            <!-- Catalog menu - start -->
            <div class="topcatalog">
                <a class="topcatalog-btn" href="<?php echo e(url('catalog')); ?>"><span>All</span> catalog</a>
                <ul class="topcatalog-list">
                    <?php $__currentLoopData = App\Models\Categories::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(url('catalog?category=' . $i->category_slug)); ?>">
                                <?php echo e(str_replace('TEMPLATES', '', strtoupper($i->category_name))); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>
            <!-- Catalog menu - end -->

            <!-- Main menu - start -->
            <button type="button" class="mainmenu-btn">Menu</button>

            <ul class="mainmenu">
                

            </ul>
            <!-- Main menu - end -->

            <!-- Search - start -->
            <div class="topsearch">
                <a id="topsearch-btn" class="topsearch-btn" href="#"><i class="fa fa-search"></i></a>
                <form class="topsearch-form" action="<?php echo e(url('catalog')); ?>" method="GET">
                    <?php if($category): ?>
                        <input type="hidden" name="category" value="<?php echo e($category); ?>">
                    <?php endif; ?>
                    <input type="text" placeholder="Search products" name="search"
                        value="<?php echo e($_GET['search'] ?? ''); ?>">
                    <button type="submit"><i class="fa fa-search"></i></button>
                </form>
            </div>
            <!-- Search - end -->

        </nav>
    </div>
</div>
<!-- Topmenu - end -->
<?php $__env->startPush('script'); ?>
    <script>
        const userID = $('.userID').data('user_id');
        $.ajax({
            url: "<?php echo e(url('/api/chart')); ?>" + `/${userID}`,
            method: 'GET',
            dataType: 'json',
            success: function(rs) {
                $('.userID').html(rs.count);
            },
            error: function(xhr, status, error) {
                console.error('Error:', error);
            }
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/core/resources/views/home/partials/topbar.blade.php ENDPATH**/ ?>