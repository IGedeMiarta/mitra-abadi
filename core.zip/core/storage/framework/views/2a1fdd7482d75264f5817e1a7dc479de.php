  <!-- Footer START -->
  <footer class="footer">
      <div class="footer-content">
          <p class="m-b-0">Copyright © 2023 <?php echo e(app_data('app')); ?></p>
      </div>
  </footer>
  <!-- Footer END -->
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/dashboard/partials/footer.blade.php ENDPATH**/ ?>