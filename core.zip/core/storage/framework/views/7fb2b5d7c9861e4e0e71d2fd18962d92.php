<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Login </title>

    <!-- Favicon -->
    

    <!-- page css -->

    <!-- Core css -->
    <link href="<?php echo e(asset('/app')); ?>/assets/css/app.min.css" rel="stylesheet">

</head>

<body>
    <div class="app">
        <div class="container-fluid">
            <div class="d-flex full-height p-v-15 flex-column justify-content-between">
                <div class="d-none d-md-flex p-h-40">

                </div>
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-md-5">
                            <div class="card">
                                <div class="card-body">
                                    <div style="">
                                        <h2 class="m-t-20 text-center">Sign In</h2>
                                        <p class="text-center">Enter your credential to get access</p>
                                        <img src="<?php echo e(asset('/logo.png')); ?>" alt="logo" class="m-b-30 "
                                            style="max-width: 300px; display: block;margin-left: auto; margin-right: auto;">

                                    </div>
                                    <form method="POST" action="">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <label class="font-weight-semibold" for="userName">Email:</label>
                                            <div class="input-affix">
                                                <i class="prefix-icon anticon anticon-mail"></i>
                                                <input type="text" class="form-control" id="userName"
                                                    placeholder="Email">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="font-weight-semibold" for="password">Password:</label>
                                            
                                            <div class="input-affix m-b-10">
                                                <i class="prefix-icon anticon anticon-lock"></i>
                                                <input type="password" class="form-control" id="password"
                                                    placeholder="Password">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="d-flex align-items-center justify-content-between">
                                                
                                                <button class="btn btn-primary">Sign In</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="offset-md-1 col-md-6 d-none d-md-block">
                            <img class="img-fluid" src="<?php echo e(asset('/login.png')); ?>" alt="">
                        </div>
                    </div>
                </div>
                <footer class="footer">
                    <div class="footer-content">
                        <p class="m-b-0">Copyright © 2023 <?php echo e(env('APP_NAME')); ?></p>
                    </div>
                </footer>
            </div>
        </div>
    </div>


    <!-- Core Vendors JS -->
    <script src="<?php echo e(asset('/app')); ?>/assets/js/vendors.min.js"></script>

    <!-- page js -->

    <!-- Core JS -->
    <script src="<?php echo e(asset('/app')); ?>/assets/js/app.min.js"></script>

</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/dashboard/auth/master.blade.php ENDPATH**/ ?>