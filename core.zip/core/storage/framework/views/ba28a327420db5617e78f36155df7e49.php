<?php $__env->startSection('content'); ?>
    <table id="myTable">
        <thead>
            <tr>
                <th>No</th>
                <th>Image</th>
                <th>Name</th>
                <th>Brand</th>
                <th>Category</th>
                <th class="text-center">Outer Size <span class="small">(mm)</span></th>
                <th class="text-center">Inner Size <span class="small">(mm)</span></th>
                <th class="text-center">Weight <span class="small">(kg)</span></th>
                <th>Price</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td class="text-center">
                        <img src="<?php echo e(asset($t->images)); ?>" alt="<?php echo e($t->product_slug); ?>" style="max-width: 100px">

                    </td>
                    <td><?php echo e($t->product_name); ?></td>
                    <td><?php echo e($t->brand->name); ?></td>
                    <td><?php echo e($t->category->category_name); ?></td>
                    <td><?php echo e($t->in_size); ?></td>
                    <td><?php echo e($t->out_size); ?></td>
                    <td><?php echo e($t->weight); ?></td>
                    <td><?php echo e(number_format($t->price, 0, '.', ',')); ?></td>
                    <td>
                        <?php echo status($t->status); ?>

                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.report.pdf.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/dashboard/report/pdf/product.blade.php ENDPATH**/ ?>