<!-- Popular Products -->
<div class="fr-pop-wrap">

    <h3 class="component-ttl"><span>Popular products</span></h3>

    <ul class="fr-pop-tabs sections-show">
        <li><a data-frpoptab-num="1" data-frpoptab="#all" href="#" class="active">All
                Categories</a></li>
        <?php $__currentLoopData = $category_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a data-frpoptab-num="<?php echo e($i + 1); ?>" data-frpoptab="#<?php echo e($item->category_slug); ?>"
                    href="#"><?php echo e(str_replace(' TEMPLATES', '', strtoupper($item->category_name))); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <div class="fr-pop-tab-cont">

        <p data-frpoptab-num="1" class="fr-pop-tab-mob active" data-frpoptab="#all">All
            Categories</p>
        <div class="flexslider prod-items fr-pop-tab" id="all">
            <ul class="slides">
                <?php $__empty_1 = true; $__currentLoopData = $product_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="prod-i">
                        <div class="prod-i-top">
                            <a href="<?php echo e(url('product/' . $pal->product_slug)); ?>"
                                class="prod-i-img"><!-- NO SPACE --><img src="<?php echo e($pal->images()); ?>"
                                    alt="Aspernatur excepturi rem"><!-- NO SPACE --></a>

                            <p class="prod-i-addwrap">
                                <a href="#" class="prod-i-add qview-btn btnDetails"
                                    style="background-color: blue; color:white" data-id="<?php echo e($pal->id); ?>"
                                    data-image="<?php echo e($pal->images()); ?>" data-name="<?php echo e($pal->product_name); ?>"
                                    data-in_size="<?php echo e($pal->in_size); ?>" data-out_size="<?php echo e($pal->out_size); ?>"
                                    data-weight="<?php echo e($pal->weight); ?>" data-price="<?php echo e($pal->price); ?>" data-disc="0"
                                    data-slug="<?php echo e($pal->product_slug); ?>"
                                    data-category="<?php echo e($pal->category->category_name); ?>"
                                    data-brandid="<?php echo e($pal->brand->id); ?>" data-brandname="<?php echo e($pal->brand->name); ?>"
                                    data-id_category="<?php echo e($pal->id_category); ?>" data-desc="<?php echo e($pal->description); ?>"><i
                                        class="fa fa-search"></i> Go to
                                    detail</a>
                            </p>
                        </div>
                        <h3>
                            <a href="<?php echo e(url('product/' . $pal->product_slug)); ?>"><?php echo e($pal->product_name); ?></a>
                        </h3>
                        <p class="prod-i-price">
                            <b class="text-primary"><?php echo e('Rp ' . number_format($pal->price, 0, '.', ',')); ?></b>
                        </p>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="alert alert-warning" role="alert">
                        No Product Available
                    </div>
                <?php endif; ?>
            </ul>

        </div>
        <?php $__currentLoopData = $category_all; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p data-frpoptab-num="2" class="fr-pop-tab-mob" data-frpoptab="#<?php echo e($item->category_slug); ?>">
                <?php echo e($item->category_name); ?>

            </p>
            <div class="flexslider prod-items fr-pop-tab" id="<?php echo e($item->category_slug); ?>">
                <?php
                    $product = App\Models\Product::with('category')
                        ->where('id_category', $item->id)
                        ->orderByDesc('id')
                        ->get();
                ?>
                <ul class="slides">
                    <?php $__empty_1 = true; $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <li class="prod-i">
                            <div class="prod-i-top">
                                <a href="<?php echo e(url('product/' . $p->product_slug)); ?>"
                                    class="prod-i-img"><!-- NO SPACE --><img src="<?php echo e($p->images()); ?>"
                                        alt="Aspernatur excepturi rem"><!-- NO SPACE --></a>

                                <p class="prod-i-addwrap">
                                    <a href="#" class="prod-i-add qview-btn btnDetails"
                                        style="background-color: blue; color:white" data-id="<?php echo e($p->id); ?>"
                                        data-image="<?php echo e($p->images()); ?>" data-name="<?php echo e($p->product_name); ?>"
                                        data-in_size="<?php echo e($p->in_size); ?>" data-out_size="<?php echo e($p->out_size); ?>"
                                        data-weight="<?php echo e($p->weight); ?>" data-price="<?php echo e($p->price); ?>"
                                        data-disc="0" data-slug="<?php echo e($p->product_slug); ?>"
                                        data-category="<?php echo e($p->category->category_name); ?>"
                                        data-brandid="<?php echo e($p->brand->id); ?>" data-brandname="<?php echo e($p->brand->name); ?>"
                                        data-id_category="<?php echo e($p->id_category); ?>" data-desc="<?php echo e($p->description); ?>"><i
                                            class="fa fa-search"></i> Go to
                                        detail</a>
                                </p>
                            </div>
                            <h3>
                                <a href="<?php echo e(url('product/' . $p->product_slug)); ?>"><?php echo e($p->product_name); ?></a>
                            </h3>
                            <p class="prod-i-price">
                                <b class="text-primary"><?php echo e('Rp ' . number_format($p->price, 0, '.', ',')); ?></b>
                            </p>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="alert alert-warning" role="alert">
                            No Product Available
                        </div>
                    <?php endif; ?>

                </ul>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



    </div><!-- .fr-pop-tab-cont -->


</div><!-- .fr-pop-wrap -->

<?php echo $__env->make('home.partials.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/core/resources/views/home/main/populars.blade.php ENDPATH**/ ?>