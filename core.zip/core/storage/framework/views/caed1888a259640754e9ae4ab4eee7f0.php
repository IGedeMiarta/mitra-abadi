<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('fav.png')); ?>">
    <title><?php echo e($title ?? ''); ?> - <?php echo e(app_data('app')); ?></title>
    <!-- page css -->

    <!-- Core css -->
    <link href="<?php echo e(asset('app')); ?>/assets/css/app.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.0/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        .form-control {
            background-color: #FAFBFD !important;
        }
    </style>
    <?php echo $__env->yieldPushContent('style'); ?>

</head>

<body>
    <div class="app">
        <div class="layout">
            <!-- Header START -->
            <?php echo $__env->make('dashboard.partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- Header END -->

            <?php echo $__env->make('dashboard.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Page Container START -->
            <div class="page-container">

                <!-- Content Wrapper START -->
                <div class="main-content">
                    <div class="page-header">
                        <h2 class="header-title"><?php echo e($title ?? ''); ?></h2>
                        <div class="header-sub-title">
                            <nav class="breadcrumb breadcrumb-dash">
                                <a href="<?php echo e(url('/dahboard')); ?>" class="breadcrumb-item"><i
                                        class="anticon anticon-home m-r-5"></i>Home</a>
                                <?php if($title != 'Dashboard'): ?>
                                    <span class="breadcrumb-item active"><?php echo e($title ?? ''); ?></span>
                                <?php endif; ?>
                            </nav>
                        </div>
                    </div>
                    <!-- Content goes Here -->
                    <?php echo $__env->yieldContent('content'); ?>

                </div>
                <!-- Content Wrapper END -->


                <?php echo $__env->make('dashboard.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
            <!-- Page Container END -->




        </div>
    </div>


    <!-- Core Vendors JS -->
    <script src="<?php echo e(asset('app')); ?>/assets/js/vendors.min.js"></script>

    <!-- page js -->

    <!-- Core JS -->
    <script src="<?php echo e(asset('app')); ?>/assets/js/app.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.0/dist/sweetalert2.all.min.js"></script>
    <script>
        $(document).ready(function() {

            // Function to add commas as a separator to the input value
            function addCommas(input) {
                return input.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            }

            // Function to remove commas from the input value
            function removeCommas(input) {
                return input.replace(/,/g, '');
            }

            // Event listener for input changes
            $('.inpNumber').on('input', function() {
                // Get the input value without commas
                var inputValue = removeCommas($(this).val());

                // Add commas to the input value
                var formattedValue = addCommas(inputValue);

                // Set the formatted value back to the input
                $(this).val(formattedValue);
            });
        });
    </script>

    <script>
        const Toast = Swal.mixin({
            toast: true,
            position: "top-end",
            showConfirmButton: false,
            timer: 3000,
            timerProgressBar: true,
            didOpen: (toast) => {
                toast.onmouseenter = Swal.stopTimer;
                toast.onmouseleave = Swal.resumeTimer;
            }
        });
    </script>
    <?php if(session('success')): ?>
        <script>
            Toast.fire({
                icon: "success",
                title: '<?php echo session('success'); ?>'
            });
        </script>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <script>
            Toast.fire({
                icon: "error",
                title: '<?php echo session('error'); ?>'
            });
        </script>
    <?php endif; ?>
    <?php if(session('createFailed')): ?>
        <script>
            $(document).ready(function() {
                $('#modalAdd').modal('show');
            });
        </script>
    <?php endif; ?>

    <?php echo $__env->yieldPushContent('script'); ?>

</body>

</html>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/dashboard/partials/app.blade.php ENDPATH**/ ?>