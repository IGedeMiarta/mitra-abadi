 <!-- Special offer -->
 <div class="discounts-wrap">
     <h3 class="component-ttl"><span>Special offer</span></h3>
     <div class="flexslider discounts-list">
         <ul class="slides">

             <?php $__currentLoopData = $special; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <li class="discounts-i">
                     <a href="<?php echo e(url('product/' . $s->product->product_slug . '?special=1')); ?>" class="discounts-i-img">
                         <img src="<?php echo e($s->product->images()); ?>" alt="Dicta doloremque">
                     </a>
                     <h3 class="discounts-i-ttl">
                         <a
                             href="<?php echo e(url('product/' . $s->product->product_slug . '?special=1')); ?>"><?php echo e($s->product->product_name); ?></a>
                     </h3>
                     <p class="discounts-i-price">
                         <del>Rp <?php echo e(number_format($s->product->price, 0, '.', ',')); ?></del>
                         <b class="text-primary">Rp <?php echo e(number_format($s->final_amount, 0, '.', ',')); ?></b>
                     </p>
                 </li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </ul>
     </div>
     <div class="discounts-info">
         <p>Special offer!<br>Limited time only</p>
         <a href="<?php echo e(url('special-catalog')); ?>">Shop now</a>
     </div>
 </div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/core/resources/views/home/main/special.blade.php ENDPATH**/ ?>