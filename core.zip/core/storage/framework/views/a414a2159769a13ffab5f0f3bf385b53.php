<?php $__env->startSection('content'); ?>
    <!-- Main Content - start -->
    <main>
        <section class="container">
            <?php echo $__env->make('home.partials.breadcubs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- Single Product - start -->
            <div class="prod-wrap">

                <!-- Product Images -->
                <div class="prod-slider-wrap">
                    <div class="prod-slider">
                        <ul class="prod-slider-car">
                            <li class="float: left; list-style: none; position: relative; width: 464px;">
                                <a data-fancybox-group="popup-product" class="fancy-img" href="<?php echo e(url($product->images)); ?>"
                                    target="_blank">
                                    <img src="<?php echo e($product->images()); ?>" alt="<?php echo e($product->name); ?>">
                                </a>
                            </li>
                        </ul>
                    </div>
                    
                </div>

                <!-- Product Description/Info -->
                <div class="prod-cont">
                    <h1 class="main-ttl"><span><?php echo e($product->product_name); ?></span></h1>
                    <div class="prod-info mb-5 row" style="margin-bottom: 10px">
                        <div class="col-md-12">
                            <p class="prod-skuttl">Brand</p>
                            <a href="<?php echo e(url('catalog?brand=' . $product->brand_id)); ?>">
                                <h3 class="item_current_price badge badge-dark"
                                    style="background-color: blue; border-radius: 0%">
                                    <?php echo e($product->brand->name); ?></h3>
                            </a>
                        </div>
                    </div>
                    <div class="prod-info row mb-5" style="margin-top: 50px">

                        <div class="col-md-4">
                            <p class="prod-skuttl">Inner Size</p>
                            <h3 class="item_current_price badge badge-primary "
                                style="background-color: gray; border-radius: 0%">
                                <?php echo e($product->in_size); ?> mm</h3>
                        </div>
                        <div class="col-md-4">
                            <p class="prod-skuttl">Outer Size</p>
                            <h3 class="item_current_price badge badge-primary "
                                style="background-color: gray; border-radius: 0%">
                                <?php echo e($product->out_size); ?> mm</h3>
                        </div>
                        <div class="col-md-4">
                            <p class="prod-skuttl">Wight</p>
                            <h3 class="item_current_price badge badge-primary "
                                style="background-color: gray; border-radius: 0%">
                                <?php echo e($product->weight); ?> Kg</h3>
                        </div>

                    </div>
                    <div class="prod-info mt-5" style="margin-top: 50px">

                        <p class="prod-price">
                            <?php if($disc): ?>
                                <del><?php echo e(nb($disc)); ?></del>
                            <?php endif; ?>
                            <b class="item_current_price text-info">
                                <?php echo e(nb($price)); ?></b>
                        </p>
                        <p class="prod-addwrap">
                            <a href="<?php echo e(url('chart-add?_xcode=' . $price * 111111 . '&product=' . $product->product_slug)); ?>"
                                class="prod-add" rel="nofollow">Add to cart</a>
                        </p>
                    </div>
                    <ul class="prod-info">
                        <p><?php echo $details; ?></p>
                    </ul>
                </div>

            </div>

            
            <?php echo $__env->make('home.partials.related', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            


        </section>
    </main>
    <!-- Main Content - end -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/core/resources/views/home/product.blade.php ENDPATH**/ ?>