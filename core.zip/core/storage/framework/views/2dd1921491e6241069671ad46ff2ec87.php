<?php $__env->startSection('content'); ?>
    <table id="myTable">
        <thead>
            <tr>
                <th>#</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Status</th>
                <th>Created At</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($t->email); ?> <br><?php echo e($t->name); ?></td>
                    <td><?php echo e($t->phone); ?></td>
                    <td><?php echo e($t->address); ?></td>
                    <td><?php echo status($t->status); ?></td>
                    <td><?php echo e(dt($t->created_at)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.report.pdf.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/dashboard/report/pdf/customer.blade.php ENDPATH**/ ?>