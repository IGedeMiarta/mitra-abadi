<?php $__env->startPush('style'); ?>
    <!-- page css -->
    <link href="<?php echo e(asset('app')); ?>/assets/vendors/datatables/dataTables.bootstrap.min.css" rel="stylesheet">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <form action="" method="POST">
        <?php echo csrf_field(); ?>
        <div class="d-flex justify-content-end ml-4 mr-4">
            <button type="submit" class="btn btn-primary mb-3"><i class="anticon anticon-check mr-2"></i>Save
                <?php echo e($title); ?></button>
        </div>

        <div class="row d-flex justify-content-center">

            <div class="card col-md-5 mr-3 ml-5">
                <div class="card-body mb-n5">
                    <h3>APP Settings</h3>
                </div>
                <hr>
                <div class="card-body mt-n5">
                    <?php $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mt-4">
                            <label for="name"><?php echo e($app->key); ?></label>
                            <input type="text" name="<?php echo e($app->key); ?>" value="<?php echo e($app->value); ?>"
                                class="form-control">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="card col-md-5 mr-3 ml-5 d-none">
                <div class="card-body mb-n5">
                    <h3>Mail Settings</h3>
                </div>
                <hr>
                <div class="card-body mt-n5">
                    <?php $__currentLoopData = $mail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mt-4">
                            <label for="name"><?php echo e($bank->key); ?></label>
                            <input type="text" name="<?php echo e($bank->key); ?>" value="<?php echo e($bank->value); ?>"
                                class="form-control">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="card col-md-5 mr-3 ml-5">
                <div class="card-body mb-n5">
                    <h3>BANK Settings</h3>
                </div>
                <hr>
                <div class="card-body mt-n5">
                    <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mt-4">
                            <label for="name"><?php echo e($bank->key); ?></label>
                            <input type="text" name="<?php echo e($bank->key); ?>" value="<?php echo e($bank->value); ?>"
                                class="form-control">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="card col-md-5 mr-3 ml-5">
                <div class="card-body mb-n5">
                    <h3>WhatsApp Settings</h3>
                </div>
                <hr>
                <div class="card-body mt-n5">
                    <?php $__currentLoopData = $wa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="mt-4">
                            <label for="name"><?php echo e($bank->key); ?></label>
                            <input type="text" name="<?php echo e($bank->key); ?>" value="<?php echo e($bank->value); ?>"
                                class="form-control">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>


        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/dashboard/settings/app.blade.php ENDPATH**/ ?>