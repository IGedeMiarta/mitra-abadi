  <table id="myTable">
      <thead>
          <tr>
              <th colspan="6"></th>
          </tr>
          <tr>
              <th colspan="6"></th>
          </tr>
          <tr>
              <th colspan="6">
                  <center>
                      <b>
                          <h2>All Selling</h2>
                      </b>
                  </center>
              </th>
          </tr>
          <tr>
              <th colspan="6"></th>
          </tr>
      </thead>
      <thead>
          <tr>
              <th>Date</th>
              <th>Status</th>
              <th>Notes</th>
              <th>TRX</th>
              <th>Customer</th>
              <th>Amount</th>
          </tr>
      </thead>
      <tbody>
          <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                  $total = 0;
                  $total += $t->amount;
              ?>
              <tr>
                  <td>
                      <span style="color: gray"> <?php echo e(dt($t->created_at)); ?></span>
                  </td>
                  <td><?php echo $t->status(); ?></td>
                  <td><?php echo e($t->info); ?></td>
                  <td><?php echo e($t->Invoice); ?></td>
                  <td><?php echo e($t->customers->name); ?></td>
                  <td><?php echo e(nb($t->amount)); ?></td>
              </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
      <?php if($table->count() > 0): ?>
          <tfoot>
              <tr style="background-color: #F3EEEA">
                  <td colspan="5" style="text-align: end">Total</td>
                  <td><?php echo e(nb($total ?? 0)); ?></td>
              </tr>
          </tfoot>
      <?php endif; ?>
  </table>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/dashboard/report/excel/sell.blade.php ENDPATH**/ ?>