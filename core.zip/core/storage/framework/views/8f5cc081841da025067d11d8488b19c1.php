 <!-- Side Nav START -->
 <?php
     $url = auth()->user()->role;
 ?>
 <div class="side-nav">
     <div class="side-nav-inner">
         <ul class="side-nav-menu scrollable">
             <li class="nav-item dropdown <?php echo e(request()->is($url . '/dashboard') ? 'active' : ''); ?>"">
                 <a href="<?php echo e(url($url . '/dashboard')); ?>">
                     <span class="icon-holder">
                         <i class="anticon anticon-home"></i>
                     </span>
                     <span class="title">Dahboard</span>
                 </a>
             </li>
             <?php if($url == 'admin'): ?>
                 <li class="nav-item dropdown">
                     <a class="dropdown-toggle" href="javascript:void(0);">
                         <span class="icon-holder">
                             <i class="anticon anticon-pie-chart"></i>
                         </span>
                         <span class="title">Master Data</span>
                         <span class="arrow">
                             <i class="arrow-icon"></i>
                         </span>
                     </a>
                     <ul class="dropdown-menu">
                         <li class="<?php echo e(request()->is($url . '/categories') ? 'active' : ''); ?>">
                             <a href="<?php echo e(url($url . '/categories')); ?>">Categories</a>
                         </li>
                         <li class="<?php echo e(request()->is($url . '/brand') ? 'active' : ''); ?>">
                             <a href="<?php echo e(url($url . '/brand')); ?>">Brand</a>
                         </li>
                         <li class="<?php echo e(request()->is($url . '/products') ? 'active' : ''); ?>">
                             <a href="<?php echo e(url($url . '/products')); ?>">Products</a>
                         </li>
                         <li class="<?php echo e(request()->is($url . '/special-products') ? 'active' : ''); ?>">
                             <a href="<?php echo e(url($url . '/special-products')); ?>">Discount Product</a>
                         </li>
                     </ul>
                 </li>
                 <li class="nav-item dropdown">
                     <a class="dropdown-toggle" href="javascript:void(0);">
                         <span class="icon-holder">
                             <i class="anticon anticon-dashboard"></i>
                         </span>
                         <span class="title">Transaction</span>
                         <span class="arrow">
                             <i class="arrow-icon"></i>
                         </span>
                     </a>
                     <ul class="dropdown-menu">
                         <li class="<?php echo e(request()->is($url . '/transaction') ? 'active' : ''); ?>">
                             <a href="<?php echo e(url($url . '/transaction')); ?>">List</a>
                         </li>
                     </ul>
                 </li>
             <?php endif; ?>


             <li class="nav-item dropdown">
                 <a class="dropdown-toggle" href="javascript:void(0);">
                     <span class="icon-holder">
                         <i class="anticon anticon-bar-chart"></i>
                     </span>
                     <span class="title">Report</span>
                     <span class="arrow">
                         <i class="arrow-icon"></i>
                     </span>
                 </a>
                 <ul class="dropdown-menu">
                     <li class="<?php echo e(request()->is($url . '/report/customer') ? 'active' : ''); ?>">
                         <a href="<?php echo e(url($url . '/report/customer')); ?>">Customer</a>
                     </li>
                     <li class="<?php echo e(request()->is($url . '/report/selling') ? 'active' : ''); ?>">
                         <a href="<?php echo e(url($url . '/report/selling')); ?>">Selling</a>
                     </li>
                     <li class="<?php echo e(request()->is($url . '/report/discount') ? 'active' : ''); ?>">
                         <a href="<?php echo e(url($url . '/report/discount')); ?>">Discount</a>
                     </li>
                     <?php if($url == 'admin'): ?>
                         <li class="<?php echo e(request()->is($url . '/report/product') ? 'active' : ''); ?>">
                             <a href="<?php echo e(url($url . '/report/product')); ?>">Product</a>
                         </li>
                         
                     <?php endif; ?>
                 </ul>
             </li>
             <li class="nav-item dropdown">
                 <a class="dropdown-toggle" href="javascript:void(0);">
                     <span class="icon-holder">
                         <i class="anticon anticon-setting"></i>
                     </span>
                     <span class="title">Settings</span>
                     <span class="arrow">
                         <i class="arrow-icon"></i>
                     </span>
                 </a>
                 <ul class="dropdown-menu">
                     <?php if($url == 'admin'): ?>
                         <li class="<?php echo e(request()->is($url . '/settings/app') ? 'active' : ''); ?>">
                             <a href="<?php echo e(url($url . '/settings/app')); ?>">APP Settings</a>
                         </li>
                     <?php endif; ?>
                     <li class="<?php echo e(request()->is($url . '/settings/user') ? 'active' : ''); ?>">
                         <a href="<?php echo e(url($url . '/settings/user')); ?>">User Settings</a>
                     </li>
                 </ul>
             </li>
         </ul>
     </div>
 </div>
 <!-- Side Nav END -->
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/dashboard/partials/sidebar.blade.php ENDPATH**/ ?>