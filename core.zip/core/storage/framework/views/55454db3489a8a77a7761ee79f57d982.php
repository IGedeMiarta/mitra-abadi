<?php $__env->startSection('content'); ?>
    <section class="container stylization maincont">

        <?php echo $__env->make('home.partials.breadcubs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <h1 class="main-ttl"><span>Forgot Password</span></h1>
        <div class="row"style="display: flex;justify-content: center">
            <div class="col-md-6">
                <form method="POST" action="<?php echo e(route('forgot.post')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Email/Phone<span
                                class="text-danger">*</span></label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control is-valid" id="inputEmail3"
                                placeholder="Enter mail or phone" name="type"
                                value="<?php echo e(Session::has('user') ? Session::get('type') : ''); ?>">
                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <?php if(Session::has('user')): ?>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Email<span
                                    class="text-danger">*</span></label>
                            <div class="col-sm-10">
                                <input type="email" class="form-control" id="inputEmail3"
                                    placeholder="Enter mail or phone" name="email"
                                    value="<?php echo e(Session::get('user')->email); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="inputEmail3" class="col-sm-2 col-form-label">Phone<span
                                    class="text-danger">*</span></label>
                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="inputEmail3"
                                    placeholder="Enter mail or phone" name="phone"
                                    value="<?php echo e(Session::get('user')->phone); ?>">
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label"></label>
                        <div class="col-sm-10 " style="display: flex;justify-content: start;margin-top: 10px">
                            <span class="">Have an account? <a href="<?php echo e(route('login')); ?>">Login</a></span>
                            <hr>
                            <span class=""> Dont have account? <a href="<?php echo e(route('register')); ?>">Register</a></span>

                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputPassword3" class="col-sm-2 col-form-label"></label>
                        <div class="col-sm-10">
                            <button type="submit"
                                class="btn btn-primary"><?php echo e(Session::has('user') ? 'RESET PASSWORD' : 'CHECK ACCOUNT'); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>



    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/home/forgot.blade.php ENDPATH**/ ?>