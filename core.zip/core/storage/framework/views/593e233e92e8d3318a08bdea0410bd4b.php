<?php $__env->startPush('style'); ?>
    <style>
        .disableBtn {
            pointer-events: none;
            cursor: default;

        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="container stylization maincont">
        <?php echo $__env->make('home.partials.breadcubs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <h1 class="main-ttl"><span>Cart</span></h1>
        <!-- Cart Items - start -->
        <form action="<?php echo e(url('trasaction')); ?>" method="POST" id="cartForm">
            <?php echo csrf_field(); ?>
            <div class="cart-items-wrap">
                <table class="cart-items">
                    <thead>
                        <tr>
                            <td class="cart-image">Photo</td>
                            <td class="cart-ttl">Products</td>
                            <td class="cart-price">Price</td>
                            <td class="cart-quantity">Quantity</td>
                            <td class="cart-summ">Summ</td>
                            <td class="cart-del">&nbsp;</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $total = 0;
                        ?>
                        <?php $__currentLoopData = $chart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $sts = $crt->product->stock > 0 ? false : true;
                            ?>
                            <tr
                                <?php if($sts): ?> style="background: linear-gradient(90deg, rgba(253,29,29,1) 3%, rgba(255,255,255,1) 100%);" <?php endif; ?>>
                                <td class="cart-image">
                                    <a href="<?php echo e(url('product/' . $crt->product->product_slug)); ?>">
                                        <img src="<?php echo e(url($crt->product->images)); ?>" alt="Similique delectus totam">
                                    </a>
                                </td>
                                <td class="cart-ttl">
                                    <a
                                        href="<?php echo e(url('product/' . $crt->product->product_slug)); ?>"><?php echo e($crt->product->product_name); ?></a>
                                    <p><b>Category: </b><?php echo e($crt->product->category->category_name); ?></p>
                                    <p><b>Brand: </b><?php echo e($crt->product->brand->name); ?></p>
                                    <p><b>Stock: </b><?php echo e($crt->product->stock); ?></p>
                                    <?php if(!$sts): ?>
                                        <input type="hidden" name="product[]" value="<?php echo e($crt->product->id); ?>">
                                    <?php endif; ?>
                                </td>
                                <td class="cart-price">
                                    <b><?php echo e(nb($crt->price)); ?></b>
                                    <?php if(!$sts): ?>
                                        <input type="hidden" name="price[]" value="<?php echo e($crt->price); ?>">
                                    <?php endif; ?>

                                </td>
                                <td class="cart-quantity">
                                    <p class="cart-qnt">

                                        <input type="number" name="qty[]" value="<?php echo e(!$sts ? $crt->qty : 0); ?>"
                                            class="form-control qtyInp" data-id="<?php echo e($crt->id); ?>"
                                            <?php if($sts): ?> disabled <?php endif; ?>>

                                    </p>
                                </td>
                                <td class="cart-summ">
                                    <b><?php echo e(nb($crt->price * $crt->qty)); ?></b>
                                    <p class="cart-forone">unit price <b><?php echo e(nb($crt->price)); ?></b></p>
                                    <?php if(!$sts): ?>
                                        <input type="hidden" name="total[]"
                                            value="<?php echo e(!$sts ? $crt->price * $crt->qty : 0); ?>">
                                    <?php endif; ?>
                                </td>
                                <td class="cart-del">
                                    <a href="<?php echo e(url('chart-del/' . $crt->id)); ?>" class="cart-remove"></a>
                                </td>
                            </tr>
                            <?php
                                $total += !$sts ? $crt->price * $crt->qty : 0;
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <ul class="cart-total">
                <li class="cart-summ">TOTAL: <b><?php echo e(nb($total)); ?></b></li>
                <input type="hidden" name="amount" id="amount" value="<?php echo e($total); ?>">
            </ul>
            <div class="cart-submit">
                <a href="#" class="cart-submit-btn" onclick="submitForm()"
                    style="<?php if($total <= 0): ?> background-color: #9EB8D9; <?php else: ?> background-color: #2B3499; <?php endif; ?>">Checkout</a>
                
                <a href="<?php echo e(url('chart-del-all')); ?>" class="cart-submit-btn"
                    style="<?php if($total <= 0): ?> background-color: #FFC5C5; pointer-events: none; <?php else: ?> background-color: #C70039 ; <?php endif; ?>">Clear
                    cart</a>
            </div>
        </form>
        <!-- Cart Items - end -->

    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        function submitForm() {
            var url = "<?php echo e(Request::url()); ?>";
            var newTab = window.open(url, '_blank');

            // Check if the new tab has been successfully opened
            if (newTab) {
                // Get the form HTML
                var formHtml = $('#cartForm').prop('outerHTML');

                // Append the form HTML to the new tab's document body
                $(newTab.document.body).html(formHtml);

                // Submit the form in the new tab
                $(newTab.document.body).find('#cartForm').submit();
            } else {
                // Handle the case where the new tab couldn't be opened
                alert('Unable to open a new tab. Please check your browser settings.');
            }
        }
        $('.qtyInp').on('change', function() {
            let qty = $(this).val();
            const id = $(this).data('id');
            $.ajax({
                url: "<?php echo e(url('/api/chart-qty')); ?>" + `${id}?qty=${qty}`,
                method: 'GET',
                dataType: 'json',
                success: function(rs) {
                    location.reload();
                },
                error: function(xhr, status, error) {
                    console.error('Error:', error);
                }
            });

        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('home.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/core/resources/views/home/chart.blade.php ENDPATH**/ ?>