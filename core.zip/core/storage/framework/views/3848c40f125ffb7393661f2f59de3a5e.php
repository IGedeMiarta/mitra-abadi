<?php $__env->startSection('content'); ?>
    <table id="myTable">
        <thead>
            <tr>
                <th>No</th>
                <th>Name</th>
                <th>Disc</th>
                <th>Last Price</th>
                <th>Final Price</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($t->product->product_name); ?></td>
                    <td><?php echo e($t->disc); ?>%</td>
                    <td>
                        <?php echo e(nb($t->product->price)); ?>

                    </td>
                    <td> <?php echo e(nb($t->final_amount)); ?></td>
                    <td><?php echo status($t->status); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.report.pdf.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/dashboard/report/pdf/discount.blade.php ENDPATH**/ ?>