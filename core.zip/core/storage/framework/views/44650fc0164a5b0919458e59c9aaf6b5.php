<?php $__env->startSection('content'); ?>
    <section class="container">
        

        <?php echo $__env->make('home.main.populars', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        

        <?php if($special->count() >= 1): ?>
            <?php echo $__env->make('home.main.special', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>


        

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/core/resources/views/home/main.blade.php ENDPATH**/ ?>