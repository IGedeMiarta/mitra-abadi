 <ul class="b-crumbs">
     <li>
         <a href="<?php echo e(url('/')); ?>">
             Home
         </a>
     </li>
     <?php echo $__env->yieldPushContent('partials.add'); ?>
     <li>
         <span><?php echo e($title ?? ''); ?></span>
     </li>
 </ul>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/core/resources/views/home/partials/breadcubs.blade.php ENDPATH**/ ?>