<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <h4>All <?php echo e($title ?? ''); ?></h4>
            <div>
                <div class="table-responsive">
                    <table id="data-table" class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Product</th>
                                <th>Stock</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <img src="<?php echo e(url($t->images)); ?>" alt="<?php echo e($t->product_slug); ?>"
                                                    style="max-width: 100px">
                                            </div>
                                            <div class="col-md-8 p-3">
                                                <b>Name :</b> <?php echo e($t->product_name); ?> <br>
                                                <b>Brand :</b> <?php echo e($t->brand->name); ?> <br>
                                                <b>Category :</b> <?php echo e($t->category->category_name); ?> <br>
                                                <b>In size :</b> <?php echo e($t->in_size); ?> <br>
                                                <b>Out Size :</b> <?php echo e($t->out_size); ?> <br>
                                                <b>Weight :</b> <?php echo e($t->weight); ?> <br>
                                                <b>Price : </b> Rp <?php echo e(number_format($t->price, 0, '.', ',')); ?> <br>

                                                <?php if($t->status): ?>
                                                    <span class="badge badge-success">ACTIVE</span>
                                                <?php else: ?>
                                                    <span class="badge badge-danger">NONACTIVE</span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo e($t->stock); ?></td>
                                    <td>

                                    </td>
                                    <td class="text-end">
                                        <button type="button" class="btn btn-info btn-sm mb-2 btnSee" data-toggle="modal"
                                            data-target="#modalSee" data-id="<?php echo e($t->id); ?>">
                                            <i class="anticon anticon-eye mr-2"></i>
                                            SEE LOG
                                        </button>
                                        <button class="btn btn-warning btn-sm btnEdit mb-2"
                                            data-url="<?php echo e(url('admin/products', $t->id)); ?>" data-id="<?php echo e($t->id); ?>"
                                            data-details="<?php echo e($t->description); ?>" data-slug="<?php echo e($t->product_slug); ?>"
                                            data-name="<?php echo e($t->product_name); ?>" data-image="<?php echo e(url($t->images)); ?>"
                                            data-in_size="<?php echo e($t->in_size); ?>" data-brand="<?php echo e($t->brand_id); ?>"
                                            data-out_size="<?php echo e($t->out_size); ?>" data-category="<?php echo e($t->id_category); ?>"
                                            data-weight="<?php echo e($t->weight); ?>"
                                            data-price="<?php echo e(number_format($t->price, 0, '.', ',')); ?>"
                                            data-status="<?php echo e($t->status); ?>"><i class="anticon anticon-edit mr-2"></i>
                                            EDIT STOK</button>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Edit-->
    <div class="modal fade" id="modalEdit">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit <?php echo e($title); ?></h5>
                    <button type="button" class="close" onclick="hideEditModal()" data-dismiss="modal">
                        <i class="anticon anticon-close" class="close"></i>
                    </button>
                </div>
                <form action="<?php echo e(url('update-stock')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group row">
                            <label for="name" class="col-sm-2 col-form-label">Product</label>
                            <div class="col-sm-10">
                                <select name="" id="productSelected" class="form-control" disabled>
                                    <option disabled>-Select</option>
                                    <?php $__currentLoopData = $editproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" data-price="<?php echo e($item->price); ?>">
                                            <?php echo e($item->product_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger">cannot edit product</span>
                            </div>
                        </div>
                        <input type="hidden" name="product" id="productId">
                        <div class="form-group row">
                            <label for="name" class="col-sm-2 col-form-label">Type</label>
                            <div class="col-sm-10">
                                <select name="type" class="form-control">
                                    <option disabled>type</option>
                                    <option value="+">+</option>
                                    <option value="-">-</option>
                                </select>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-sm-2 col-form-label">Stock</label>
                            <div class="col-sm-10">
                                <input type="number" name="stock" id="" class="form-control">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label for="name" class="col-sm-2 col-form-label">Notes</label>
                            <div class="col-sm-10">
                                <textarea name="note" id="" cols="30" rows="3" class="form-control"></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- Modal See-->
    <div class="modal fade" id="modalSee">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Details Product</h5>
                    <button type="button" class="close" data-dismiss="modal" onclick="hideSeeModal()"
                        aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table id="data-table" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Type</th>
                                    <th>Start </th>
                                    <th>End </th>
                                    <th>Notes</th>
                                    <th>By</th>

                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody id="tbody">

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        $('.close').on('click', function() {
            $(this).modal('hide');
        })

        function hideEditModal() {
            $('#modalEdit').modal('hide');
        }

        function hideSeeModal() {
            $('#modalSee').modal('hide');
        }

        $('.btnEdit').on('click', function(e) {
            e.preventDefault();
            const url = $(this).data('url');
            const id = $(this).data('id');
            console.log(id);
            $('#productId').val(id);
            $('#productSelected').val(id);
            $('#modalEdit').modal('show');
        })
        $('.btnSee').on('click', function() {
            const id = $(this).data('id');
            $.ajax({
                url: "<?php echo e(url('stock-log')); ?>" + "/" + id,
                success: function(result) {
                    $('#tbody').html(result.table)
                }
            });

        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/core/resources/views/dashboard/stock.blade.php ENDPATH**/ ?>