<?php $__env->startPush('style'); ?>
    <style type="text/css">
        .pagination li {
            float: left;
            list-style-type: none;
            margin: 5px;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <section class="container">
        <?php echo $__env->make('home.partials.breadcubs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <h1 class="main-ttl"><span><?php echo e($title ?? ''); ?></span></h1>
        <div class="prod-wrap">
            <div class="section-catalog">
                <?php
                    $category = isset($_GET['category']) ? $_GET['category'] : false;
                    $search = isset($_GET['search']) ? $_GET['search'] : false;
                    $author = isset($_GET['author']) ? $_GET['author'] : false;
                    $query = '';
                    if ($category) {
                        $query .= '&category=' . $category;
                    }
                    if ($search) {
                        $query .= '&search=' . $search;
                    }
                    if ($author) {
                        $query .= '&author=' . $author;
                    }
                ?>
                <!-- Pagination - start -->
                <div style="display:flex;justify-content:center">
                    <ul class="pagi ">
                        
                        <?php
                            $totalPages = $catalog->lastPage();
                            $currentPage = $catalog->currentPage();
                            $result = calculatePages($currentPage, $totalPages);
                        ?>
                        <?php if($catalog->currentPage() != 1): ?>
                            <li class="pagi-next">
                                <a href="<?php echo e($catalog->previousPageUrl() . $query); ?>"><i
                                        class="fa fa-angle-double-left"></i></a>
                            </li>
                        <?php endif; ?>
                        <?php for($i = $result['startPage'] - 1 != 0 ? $result['startPage'] - 1 : $result['startPage']; $i <= $result['lastPage']; $i++): ?>
                            <li class="<?php if($catalog->currentPage() == $i): ?> active <?php endif; ?>"><a
                                    href="<?php echo e(url('catalog?page=' . $i . $query)); ?>"><?php echo e($i); ?></a>
                            </li>
                        <?php endfor; ?>
                        <?php if($catalog->currentPage() != $catalog->lastPage()): ?>
                            <li class="pagi-next">
                                <a href="<?php echo e($catalog->nextPageUrl() . $query); ?>"><i
                                        class="fa fa-angle-double-right"></i></a>
                            </li>
                        <?php endif; ?>

                    </ul>
                </div>
                <div class="prod-items section-items prod-items-galimg">
                    <?php $__empty_1 = true; $__currentLoopData = $catalog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="prod-i" style="margin-bottom: 5px">
                            <div class="prod-i-top">
                                <a href="<?php echo e(url('product/' . $cal->product_slug)); ?>" class="prod-i-img">
                                    <!-- NO SPACE -->
                                    <img src="<?php echo e($cal->images); ?>" alt="Nulla numquam obcaecati">

                                </a>
                            </div>
                            <h3>
                                <a href="<?php echo e(url('product/' . $cal->product_slug)); ?>"><?php echo e($cal->product_name); ?></a>
                            </h3>
                            <div class="prod-i-action">
                                <p class="prod-i-info">
                                    <a href="#" class="prod-i-add qview-btn btnDetails"
                                        style="background-color: blue; color:white" data-id="<?php echo e($cal->id); ?>"
                                        data-image="<?php echo e(asset($cal->images)); ?>" data-name="<?php echo e($cal->product_name); ?>"
                                        data-in_size="<?php echo e($cal->in_size); ?>" data-out_size="<?php echo e($cal->out_size); ?>"
                                        data-weight="<?php echo e($cal->weight); ?>" data-price="<?php echo e($cal->price); ?>" data-disc="0"
                                        data-slug="<?php echo e($cal->product_slug); ?>"
                                        data-category="<?php echo e($cal->category->category_name); ?>"
                                        data-brandid="<?php echo e($cal->brand->id); ?>" data-brandname="<?php echo e($cal->brand->name); ?>"
                                        data-id_category="<?php echo e($cal->id_category); ?>" data-desc="<?php echo e($cal->description); ?>"><i
                                            class="fa fa-search"></i> Go to
                                        detail</a>
                                </p>
                                <p class="prod-i-price">
                                    <b class="text-info">Rp <?php echo e(number_format($cal->price, 0, ',', '.')); ?></b>
                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="alert alert-warning" role="alert">
                            No Product Available
                        </div>
                    <?php endif; ?>

                </div>
                <!-- Pagination - start -->
                <div style="display:flex;justify-content:center">
                    <ul class="pagi ">

                        <?php if($catalog->currentPage() != 1): ?>
                            <li class="pagi-next">
                                <a href="<?php echo e($catalog->previousPageUrl() . $query); ?>"><i
                                        class="fa fa-angle-double-left"></i></a>
                            </li>
                        <?php endif; ?>
                        <?php for($i = $result['startPage'] - 1 != 0 ? $result['startPage'] - 1 : $result['startPage']; $i <= $result['lastPage']; $i++): ?>
                            <li class="<?php if($catalog->currentPage() == $i): ?> active <?php endif; ?>"><a
                                    href="<?php echo e(url('catalog?page=' . $i . $query)); ?>"><?php echo e($i); ?></a>
                            </li>
                        <?php endfor; ?>
                        <?php if($catalog->currentPage() != $catalog->lastPage()): ?>
                            <li class="pagi-next">
                                <a href="<?php echo e($catalog->nextPageUrl() . $query); ?>"><i
                                        class="fa fa-angle-double-right"></i></a>
                            </li>
                        <?php endif; ?>

                    </ul>
                </div>

                <!-- Pagination - end -->
            </div>
        </div>
        <?php echo $__env->make('home.partials.related', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Catalog Items | Gallery V2 - start -->

        <?php echo $__env->make('home.partials.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



        <!-- Quick View Product - end -->
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('home.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/home/catalog.blade.php ENDPATH**/ ?>