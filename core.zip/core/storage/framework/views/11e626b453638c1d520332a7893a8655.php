<?php $__env->startPush('style'); ?>
    <!-- page css -->
    <link href="<?php echo e(asset('app')); ?>/assets/vendors/datatables/dataTables.bootstrap.min.css" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" />
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" />
    <style>
        .bg-grey {
            background-color: #c0c5ce
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <?php
        $filter = $_GET['filter'] ?? 'all';
    ?>
    <div class="card">
        <div class="card-body">
            <h4>All <?php echo e($title ?? ''); ?></h4>
            <hr>
            <div class="d-flex justify-content-end">
                <div class="btn-group btn-group-toggle" data-toggle="buttons">
                    <label class="btn btn-secondary active" <?php if(true): echo 'disabled'; endif; ?>>
                        <input type="radio" name="options" id="option1" autocomplete="off" checked> Export As:
                    </label>
                    <label class="btn btn-danger " id="btnPDF">
                        <i class="anticon anticon-file-pdf"></i> PDF
                    </label>
                    <label class="btn btn-success" id="btnExcel">
                        <i class="anticon anticon-file-excel"></i> Excel
                    </label>
                </div>
            </div>
            <hr>
            <div class="table-responsive" id="myTable">
                <table id="data-table" class="table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Name</th>
                            <th>Disc</th>
                            <th>Last Price</th>
                            <th>Final Price</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($t->product->product_name); ?></td>
                                <td><?php echo e($t->disc); ?>%</td>
                                <td>
                                    <?php echo e(nb($t->product->price)); ?>

                                </td>
                                <td> <?php echo e(nb($t->final_amount)); ?></td>
                                <td><?php echo status($t->status); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                </table>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <!-- page js -->
    <script src="<?php echo e(asset('app')); ?>/assets/vendors/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('app')); ?>/assets/vendors/datatables/dataTables.bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"
        integrity="sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg=="
        crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script>
        $('#data-table').DataTable();
        $('#btnPDF').on('click', function(e) {
            const url = "<?php echo e(route('admin.report.pdf', 'discount')); ?>";
            window.open(url, '_blank');
        });
        $('#btnExcel').on('click', function(e) {
            const url = "<?php echo e(route('admin.report.excel', 'discount')); ?>";
            window.open(url);
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/core/resources/views/dashboard/report/discount.blade.php ENDPATH**/ ?>