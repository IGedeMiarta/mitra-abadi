<?php $__env->startSection('content'); ?>
    <table id="data-table" class="table">
        <thead>
            <tr>
                <th>Status</th>
                <th>Notes</th>
                <th>TRX</th>
                <th>Customer</th>
                <th>Amount</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $total_aprove = 0;
            ?>
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $total_aprove += $t->status == 2 ? $t->amount : 0;
                ?>

                <tr>
                    <td>
                        <span style="color: gray"> <?php echo e(dt($t->created_at)); ?> <br> <?php echo $t->status(); ?></span>
                    </td>
                    <td><?php echo $t->info ?? '<i style="color: gray">noInfo</i>'; ?></td>
                    <td><?php echo e($t->Invoice); ?></td>
                    <td>
                        <a href="#"><?php echo e($t->customers->name); ?></a>
                        <br>
                        <?php echo e($t->customers->phone); ?>

                        <br>
                        <?php echo e($t->customers->address); ?>


                    </td>
                    <td><?php echo e(nb($t->amount)); ?></td>
                    <td>
                        <ul class="list-group">
                            <table class="table table-bordered">
                                <?php $__currentLoopData = $t->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($d->product->product_name); ?>.</td>
                                        <td><?php echo e($d->qty); ?></td>
                                        <td><?php echo e('@' . nb($d->price)); ?></td>
                                        <td><?php echo e(nb($d->total)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </table>
                        </ul>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <?php if($table->count() > 0): ?>
            <tfoot>
                <tr style="background-color: #F3EEEA">
                    <td colspan="4" style="text-align: end">Total Approve</td>
                    <td><?php echo e(nb($total_aprove ?? 0)); ?></td>
                    <td></td>
                </tr>
            </tfoot>
        <?php endif; ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.report.pdf.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/dashboard/report/pdf/sell.blade.php ENDPATH**/ ?>