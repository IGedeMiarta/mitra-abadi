<?php $__env->startSection('content'); ?>
    <section class="container stylization maincont">
        <?php echo $__env->make('home.partials.breadcubs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <hr>
        <div class="row" style="margin-top: 10px">
            <div class="col-md-5">
                <form action="<?php echo e(url('profile', auth()->user()->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>;
                    <h1 class="main-ttl"><span><?php echo e('USER ACCOUNT'); ?></span></h1>

                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Email</label>
                        <div class="col-sm-10">
                            <input type="email" class="form-control" id="inputEmail3" placeholder="Enter Email"
                                name="email" value="<?php echo e($user->email); ?>" disabled>
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Phone Number<span
                                class="text-danger">*</span></label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="inputEmail3" placeholder="Phone Number"
                                name="phone" value="<?php echo e($user->phone); ?>" disabled>
                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Name</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="inputEmail3" placeholder="Enter Name"
                                name="name" value="<?php echo e($user->name); ?>">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="inputEmail3" class="col-sm-2 col-form-label">Address<span
                                class="text-danger">*</span></label>
                        <div class="col-sm-10">
                            <textarea name="address" placeholder="Address.." id="" cols="30" rows="10"><?php echo e($user->address); ?></textarea>
                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="d-flex" style="display: flex; justify-content: end">
                        <div class="cart-submit">
                            <button type="submit" class="cart-submit-btn" style="background-color: #525CEB">
                                Update</button>
                        </div>
                </form>
                <form action="<?php echo e(url('/logout')); ?>" id="form" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="cart-submit">
                        <a href="#" class="cart-submit-btn" style="background-color: #FA7070" onclick="submitForm()">
                            LOGOUT</a>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-7">
            <h1 class="main-ttl"><span><?php echo e('Order History'); ?></span></h1>

            <div class="cart-items-wrap">
                <table class="cart-items">
                    <thead>
                        <tr>
                            <td class="cart-ttl">Products</td>
                            <td class="cart-date">Date</td>
                            <td class="cart-price">Price</td>
                            <td class="cart-summ">Payment Details</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>

                                <td class="cart-ttl">
                                    <a href="<?php echo e(url('invoice/' . $item->Invoice)); ?>" target="_blank"
                                        style="color: #7071E8">#<?php echo e($item->Invoice); ?></a>

                                    <?php $__currentLoopData = $item->details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><?php echo e($d->qty . ' | ' . $d->product->product_name); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </td>
                                <td class="cart-date" style="color:#7D7C7C"><?php echo e(dates($item->created_at)); ?></td>


                                <td class="cart-price">
                                    <b><?php echo e(nb($item->amount)); ?></b> <br>
                                    <b><?php echo $item->status(); ?></b><br>
                                    <b>Shipment: <?php echo $item->shipment(); ?></b>
                                </td>
                                
                                <td>
                                    <?php if($item->trx_img_2 === null && ($item->dp != 0 || $item->trx_img_1 === null)): ?>
                                        <button class="cart-submit-btn qview-btn btnUpload"
                                            style="background-color: #86A7FC" data-inv="#<?php echo e($item->Invoice); ?>"
                                            data-price="<?php echo e(nb($item->amount)); ?>" data-id="<?php echo e($item->id); ?>"
                                            data-url="<?php echo e(url('invoice/' . $item->Invoice)); ?>">Upload
                                            Struk </button>
                                    <?php else: ?>
                                        <img src="<?php echo e(asset($item->trx_img_1)); ?>" alt="img-<?php echo e($item->Invoice); ?>">
                                    <?php endif; ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td colspan="4">
                                <b>
                                    <center>
                                        No orders yet!
                                    </center>
                                </b>
                            </td>
                        <?php endif; ?>

                    </tbody>
                </table>
            </div>
        </div>
        </div>

    </section>
    <?php echo $__env->make('home.modal-upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
        function submitForm() {
            // Submit the form
            document.getElementById('form').submit();
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('home.partials.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/app-penjualan/resources/views/home/profile.blade.php ENDPATH**/ ?>