 <!-- latest product -->
 <div class="latest-product segments no-pd-b">
     <div class="container">
         <div class="section-title">
             <h3>Latest</h3>
         </div>
         <div class="row">
             <div class="col-50">
                 <div class="content content-shadow-product">
                     <a href="/product-details/">
                         <div class="image">
                             <img src="{{ asset('app') }}/assets/images/others/product-1.jpg" alt="product">
                         </div>
                         <div class="text">
                             <p class="title-product title-product-center">Elegant Blue t-Shirt
                             </p>
                             <p class="price">$80.00</p>
                         </div>
                     </a>
                 </div>
             </div>
             <div class="col-50">
                 <div class="content content-shadow-product">
                     <a href="/product-details/">
                         <div class="image">
                             <img src="{{ asset('app') }}/assets/images/others/produc-2.jpg" alt="product">
                         </div>
                         <div class="text">
                             <p class="title-product title-product-center">Elegant Blue t-Shirt
                             </p>
                             <p class="price">$80.00</p>
                         </div>
                     </a>
                 </div>
             </div>

         </div>
     </div>
 </div>
 <!-- end latest product -->
