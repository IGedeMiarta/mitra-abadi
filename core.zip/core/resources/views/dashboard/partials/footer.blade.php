  <!-- Footer START -->
  <footer class="footer">
      <div class="footer-content">
          <p class="m-b-0">Copyright © 2023 {{ app_data('app') }}</p>
      </div>
  </footer>
  <!-- Footer END -->
